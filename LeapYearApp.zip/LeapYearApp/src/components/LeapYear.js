import React from 'react';
import './LeapYear.css';

class LeapYear extends React.Component{
  constructor(props)
  {
    super(props);

    this.state ={
      year : '',
    }

    this.fieldRef = React.createRef();
  }

  handleOnChange = (e) =>
  {
    this.setState({
      year : e.target.value
    })
  }

  checkLeap = () =>
  {
    let year = isNaN(this.state.year) ? -1 : parseInt(this.state.year);
    //console.log(isNaN(this.state.year));
    let flag=0;
  //  console.log(year);
    if(isNaN(year) || year === -1){
      this.fieldRef.current.innerHTML = "Please enter a year";
      this.fieldRef.current.style.color = "red";

    }
    else{
      let leap = (year % 100 === 0) ? (year % 400 === 0) : (year % 4 === 0);
    //  console.log(leap);

      if(leap===true){
        this.fieldRef.current.innerHTML = year +" is a Leap Year";
        this.fieldRef.current.style.color = "orange";

      }
      else{
        this.fieldRef.current.innerHTML = year+" is not a Leap Year";
        this.fieldRef.current.style.color = "red";
      }
  }
    console.log(this.fieldRef);
  }


  render(){
  return (
    <section className= "App">
    <div className = "center">
      <h1 id="heading">Leap Year App</h1>
      <h2 className="leap">Enter any year : <input type="text" value={ this.state.year } onChange={ this.handleOnChange }></input></h2>

      <button className="button" onClick = { this.checkLeap }>Check</button>

      <p className="leap" ref ={ this.fieldRef }></p>
    </div>
    </section>
  );
}
}

export default LeapYear;
