import './App.css';
import React from 'react';
import LeapYear from './components/LeapYear';


class App extends React.Component{
  render(){
    return(
      <div>
      {/*<h1 className="App">LeapYear App</h1>*/}
      <LeapYear />
      </div>
    )
  }
}

export default App;
